# WP GraphQL Smart Cache - BETA USERS

If you've been contacted to beta test this plugin, you can access the docs here: https://docs.google.com/document/d/16n2LxJB5POBkkWF6OIC9et1BogLMiRf6qZwL7ofBT5k/edit?usp=sharing
