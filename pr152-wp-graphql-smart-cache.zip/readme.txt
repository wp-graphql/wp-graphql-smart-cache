=== WP GraphQL Persisted Queries ===
Contributors: markkelnar, jasonbahl
Tags: GraphQL
Requires at least: 4.5
Tested up to: 5.6.1
Requires PHP: 5.6
Stable tag: 0.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

WPGraphQL Persisted Queries for WPGraphQL, a plugin that provides an extendable GraphQL schema and API for any WordPress site.

== Changelog ==

= 0.1.1 =

- Initial release to beta users
